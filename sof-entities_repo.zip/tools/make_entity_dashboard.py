# -*- coding: utf-8 -*-
"""Entity_DB xlsx -> self-contained RTL dashboard (entity browser + presence matrix).
Usage: python3 make_entity_dashboard.py <Entity_DB.xlsx> <out.html> [spine_label]
One-way: the DB is the source of truth; the page is regenerated, never edited by hand."""
import sys, json, re, datetime, openpyxl

args = [a for a in sys.argv[1:] if not a.startswith('--')]
PUBLIC = '--public' in sys.argv  # public build: no manuscript sentences, no notes/TK
SRC, OUT = args[0], args[1]
LABEL = args[2] if len(args) > 2 else SRC.split('/')[-1]
wb = openpyxl.load_workbook(SRC, data_only=True)

def rows(name):
    ws = wb[name]
    it = ws.iter_rows(values_only=True)
    hdr = [str(h).strip() if h is not None else '' for h in next(it)]
    out = []
    for r in it:
        if all(v is None or str(v).strip() == '' for v in r):
            continue
        out.append({hdr[i]: ('' if v is None else str(v).strip()) for i, v in enumerate(r) if i < len(hdr)})
    return out

TYPE_CODE = {'אישים': 'P', 'יחידות': 'U', 'ארגונים ומוסדות': 'O', 'אירועים': 'E', 'מקומות': 'L',
             'תאריכים מרכזיים': 'D', 'מפגשים קריטיים': 'M'}
TYPE_ORDER = ['P', 'U', 'O', 'E', 'L', 'D', 'M']
TYPE_NAME = {v: k for k, v in TYPE_CODE.items()}

# ---- colors (from the DB; dark variants derived) ----
def hex2rgb(h): h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def rgb2hex(c): return '#%02X%02X%02X' % tuple(max(0, min(255, int(round(x)))) for x in c)
def mix(a, b, t): return tuple(a[i] * (1 - t) + b[i] * t for i in range(3))
colors = {}
for r in rows('צבעים'):
    code = r.get('קוד', '')
    if code in TYPE_ORDER:
        full = hex2rgb(r['צבע מלא (hex)'])
        colors[code] = {
            'light_full': rgb2hex(full),
            'light_soft': rgb2hex(mix(full, (255, 255, 255), 0.78)),
            'dark_full': rgb2hex(mix(full, (255, 255, 255), 0.42)),
            'dark_soft': rgb2hex(mix(full, (28, 31, 36), 0.62)),
            'name': r.get('שם צבע', ''),
        }

# ---- entities ----
ents = []
extra = {}
for sheet in ['אישים', 'יחידות', 'ארגונים ומוסדות', 'אירועים', 'מקומות', 'תאריכים', 'מפגשים']:
    for r in rows(sheet):
        extra[r['מזהה']] = r
for r in rows('ישויות'):
    eid = r['מזהה']
    code = eid.split('-')[0]
    x = extra.get(eid, {})
    e = {
        'id': eid, 't': code, 'name': r['שם קנוני'],
        'variants': [v.strip() for v in r['גרסאות שם'].split(';') if v.strip()],
        'first': r['הופעה ראשונה (S¶)'], 'firstS': r['תת-פרק ראשון'],
        'n': int(float(r['מספר הופעות'] or 0)), 'index': r['צורת אינדקס'],
        'cert': r['ודאות'], 'src': r['מקור'], 'notes': r['הערות/TK'],
    }
    for k_src, k in [('שנות חיים', 'life'), ('תפקיד בהופעה הראשונה', 'role'), ('תאריך ISO', 'iso'), ('תיאור', 'desc'),
                     ('משתתפים (P ids)', 'participants'), ('תאריך', 'date'), ('מקום (L id)', 'place'), ('מה השתנה', 'change')]:
        if x.get(k_src):
            e[k] = x[k_src]
    ents.append(e)
by_id = {e['id']: e for e in ents}

# ---- appearances ----
apps = {}
for r in rows('הופעות'):
    eid = r['מזהה']
    if eid not in by_id:
        continue
    apps.setdefault(eid, []).append({
        's': r['תת-פרק'], 'p': int(float(r['פסקה'])) if r['פסקה'] else None,
        'as': r['שם כפי שמופיע'], 'first': r['ראשונה?'] == 'כן', 'ctx': r['הקשר'],
    })
for e in ents:
    e['apps'] = sorted(apps.get(e['id'], []), key=lambda a: (a['s'], a['p'] or 0))
    e['subs'] = sorted({a['s'] for a in e['apps']})
    if PUBLIC:
        for a in e['apps']:
            a['ctx'] = ''
        e['notes'] = ''

# ---- spine: S01..S50 titles/dates + planned first appearances (register v1.1) ----
spine = {}
planned = {}
for r in rows('רשימת הופעות ראשונות v1.1'):
    sid = r.get('תת-פרק (מזהה)', '')
    if re.fullmatch(r'S\d{2}', sid):
        spine.setdefault(sid, {'dates': r.get('תאריכי תת-הפרק', ''), 'title': r.get('כותרת תת-הפרק', '')})
        planned.setdefault(sid, []).append({'name': r.get('ישות', ''), 'type': r.get('סוג', ''), 'cert': r.get('ודאות', '')})
sids = ['S%02d' % i for i in range(1, 51)]
for s in sids:
    spine.setdefault(s, {'dates': '', 'title': ''})

# match planned rows to DB entities by name/variant
name_index = {}
for e in ents:
    for v in [e['name']] + e['variants']:
        name_index.setdefault(v, e['id'])
plan_by_ent = {}
plan_only = []
for sid, lst in planned.items():
    for pr in lst:
        eid = name_index.get(pr['name'])
        if eid:
            plan_by_ent.setdefault(eid, [])
            if sid not in plan_by_ent[eid]:
                plan_by_ent[eid].append(sid)
        else:
            tcode = {'אדם': 'P', 'יחידה': 'U', 'ארגון': 'O', 'אירוע': 'E', 'מקום': 'L', 'תאריך': 'D', 'מפגש': 'M'}.get(pr['type'], 'P')
            plan_only.append({'name': pr['name'], 't': tcode, 's': sid, 'cert': pr['cert']})
for e in ents:
    e['planned'] = sorted(plan_by_ent.get(e['id'], []))
# fold plan-only rows (same name -> one row, many sub-chapters)
po = {}
for p in plan_only:
    k = (p['name'], p['t'])
    po.setdefault(k, {'name': p['name'], 't': p['t'], 'planned': [], 'cert': p['cert']})
    if p['s'] not in po[k]['planned']:
        po[k]['planned'].append(p['s'])
plan_only = sorted(po.values(), key=lambda p: (TYPE_ORDER.index(p['t']), p['planned'][0] if p['planned'] else ''))
for p in plan_only:
    p['planned'].sort()

counts = {c: sum(1 for e in ents if e['t'] == c) for c in TYPE_ORDER}
per_sub = {}
for e in ents:
    for a in e['apps']:
        d = per_sub.setdefault(a['s'], {'ents': set(), 'first': 0, 'apps': 0})
        d['ents'].add(e['id']); d['apps'] += 1
        if a['first']:
            d['first'] += 1
per_sub = {k: {'ents': len(v['ents']), 'first': v['first'], 'apps': v['apps']} for k, v in per_sub.items()}

data = {
    'label': LABEL, 'built': datetime.date.today().isoformat(),
    'types': [{'code': c, 'name': TYPE_NAME[c]} for c in TYPE_ORDER],
    'colors': colors, 'ents': ents, 'sids': sids, 'spine': spine, 'perSub': per_sub,
    'planOnly': plan_only, 'counts': counts, 'nApps': sum(e['n'] for e in ents), 'public': PUBLIC,
}

# ---- CSS color tokens ----
def tok(block):
    return '\n'.join('  --c-%s: %s; --c-%s-soft: %s;' % (c, colors[c]['%s_full' % block], c, colors[c]['%s_soft' % block]) for c in TYPE_ORDER)

TEMPLATE = open(__file__.replace('make_entity_dashboard.py', 'dashboard_template.html'), encoding='utf-8').read()
html = (TEMPLATE
        .replace('/*LIGHT_TYPE_TOKENS*/', tok('light'))
        .replace('/*DARK_TYPE_TOKENS*/', tok('dark'))
        .replace('/*DATA*/', json.dumps(data, ensure_ascii=False).replace('</', '<\\/')))
open(OUT, 'w', encoding='utf-8').write(html)
print('entities', len(ents), 'appearances', data['nApps'], 'plan-only', len(plan_only), '->', OUT, len(html.encode()), 'bytes')
