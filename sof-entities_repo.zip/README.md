# מאגר הישויות — ספר ה-SOF

לוח ישויות ומטריצת נוכחות, נבנים חד-כיוונית מ-`data/Entity_DB.xlsx`.

- `data/Entity_DB.xlsx` — מקור האמת (נוצר מהטקסט המתויג בכספת).
- `tools/make_entity_dashboard.py` + `tools/dashboard_template.html` — המחולל.
- `docs/index.html` — הבנייה האחרונה (גרסה ציבורית, בלי משפטי ההקשר).
- `.github/workflows/pages.yml` — בכל דחיפה ל-`main` שמשנה את המאגר או את הכלים, הדף נבנה מחדש ומתפרסם ב-GitHub Pages.

מצב הבנייה: ברירת המחדל `--public` (בלי משפטי ההקשר מכתב היד ובלי הערות TK). להציג את הגרסה המלאה: משתנה ריפו `DASHBOARD_MODE=full` (Settings → Variables).

בנייה מקומית:

```
pip install openpyxl
python3 tools/make_entity_dashboard.py data/Entity_DB.xlsx index.html Entity_DB.xlsx [--public]
```
